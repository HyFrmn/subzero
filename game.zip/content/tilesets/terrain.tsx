<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Terrain" tilewidth="32" tileheight="32">
 <image source="../tiles/terrain_tiles.png" width="32" height="32"/>
</tileset>
