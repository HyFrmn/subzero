<?xml version="1.0" encoding="UTF-8"?>
<tileset name="entities" tilewidth="32" tileheight="32">
 <properties>
  <property name="xtype" value="spawn.pc"/>
 </properties>
 <image source="../tiles/entities.png" trans="00ff00" width="192" height="32"/>
</tileset>
