<?xml version="1.0" encoding="UTF-8"?>
<tileset name="MegaBlock" tilewidth="32" tileheight="32">
 <image source="../tiles/base_tiles.png" width="256" height="256"/>
</tileset>
